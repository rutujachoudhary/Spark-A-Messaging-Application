import {User} from './app.user';

export class Message{
    text:string;
    date:Date;
    sender:User;
    receiver:User;
}

         
