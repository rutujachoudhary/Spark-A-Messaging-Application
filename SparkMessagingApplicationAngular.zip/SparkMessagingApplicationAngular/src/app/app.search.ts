import { Component, OnInit } from "@angular/core";
import { MessageService } from "./app.MessageService";
import {ActivatedRoute, Params} from '@angular/router';
import {Message} from './app.message';


@Component({
    selector: 'search-app',
    templateUrl: 'app.search.html'
})



export  class  SearchMessage  implements  OnInit {
    messages: Message[];
    model: number;
    constructor(private  msgservice: MessageService) { }
    ngOnInit() { }
    searchMessage() {
        console.log("search by id..."+this.model);
        this.msgservice.searchMessage(this.model).subscribe((data: any) => this.messages = data);
    }

} 