import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';


@Injectable({
    providedIn: 'root'
})

export class MessageService {

    constructor(private http: HttpClient) { }

    addMessage(msg: any) {
        let input = new FormData();
        /**key is the attribute from particular class also defined in postman */
        input.append("text", msg.text);
        input.append("sender_id", msg.sender_id);
        input.append("sender_name", msg.sender_name);
        input.append("receiver_id", msg.receiver_id);
        input.append("receiver_name", msg.receiver_name);

        return this.http.post("http://localhost:9093/chathistory/add", input);
    }

    showChatHistory() {
        console.log("inside show history...." + this.http.get("http://localhost:9093/chathistory/show"));
        return this.http.get("http://localhost:9093/chathistory/show").pipe(
        retry(1),
        catchError(this.handleError)
      );
    }


    searchMessage(msgs: any) {
        let input = new FormData();
        // input.append("uid", msgs.sender_id);
        // input.append("uid", msgs.receiver_id);
        console.log("In search"+msgs);
        let params = new HttpParams().set("uid",msgs);
        return this.http.post("http://localhost:9093/chathistory/search",params).pipe(
        retry(1),
        catchError(this.handleError)
      );
        // return this.http.post("http://localhost:9093/chathistory/search", input);
    }

     handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error}`;
    } else {
      // server-side error
      errorMessage = `${error.error}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }
}

