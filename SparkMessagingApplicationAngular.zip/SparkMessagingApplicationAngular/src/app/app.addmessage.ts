import {Component} from '@angular/core';
import {MessageService} from './app.messageservice';
import {Message} from './app.message';
import {User} from './app.user';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
    selector: 'msg-app',
    templateUrl: 'app.addmessage.html'
})



export class MessageComponent {

    registerForm : FormGroup;
    submitted = false;

    messages: Message[];
    model: any = {};
    msg:string="Added Succesfully";
  

    constructor(private msgservice: MessageService, private formBuilder: FormBuilder) {
        console.log("In Constructor");
    }
    ngOnInit() {
        this.registerForm  = this.formBuilder.group({
            text: ['', Validators],
            senderId: ['', Validators.required],
            senderName: ['', Validators.required],
            receiverId: ['', Validators.required],
            receiverName: ['', Validators.required]
        });
    }

    addMessage() {
        //  this.submitted = true;

        // // stop here if form is invalid
        // if (this.registerForm.invalid) {
        //     return;
        // }
          this.model.text=this.registerForm.value.text;
        this.model.sender_id=this.registerForm.value.senderId;
        this.model.sender_name=this.registerForm.value.senderName;
        this.model.receiver_id=this.registerForm.value.receiverId;
        this.model.receiver_name=this.registerForm.value.receiverName;

     
        

            // this.model.senderId=" ";
            // this.model.senderName=" ";
            // this.model.receiverId=" ";
            // this.model.receiverName=" ";
 
  return  this.msgservice.addMessage(this.model).subscribe((data: any) => console.log(data));
    }


    // convenience getter for easy access to form fields


}