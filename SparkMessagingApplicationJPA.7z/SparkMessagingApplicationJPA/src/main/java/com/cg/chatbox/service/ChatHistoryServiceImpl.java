package com.cg.chatbox.service;

import java.util.List;

import com.cg.chatbox.dao.ChatHistoryDaoImpl;
import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;

public class ChatHistoryServiceImpl implements ChatHistoryService {
	ChatHistoryDaoImpl dao = new ChatHistoryDaoImpl();
	static int msg_id =1;
	public Message addMessage(Message message) throws UserException {
		message.setId(msg_id);
		msg_id++;
		return dao.saveMessage(message);
	}

	public List<Message> searchBySenderOrReceiver(User user) throws UserException {
		return dao.findBySenderOrReceiver(user);
	}

	public List<ChatHistory> getAllChatHistory() {
		return dao.getAllChatHistory();
	}

}
