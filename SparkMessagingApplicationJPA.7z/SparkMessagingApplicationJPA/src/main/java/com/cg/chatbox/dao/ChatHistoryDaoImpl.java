package com.cg.chatbox.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;
import com.cg.chatbox.util.DBUtil;

public class ChatHistoryDaoImpl implements ChatHistoryDao {
	EntityManager em;

	public ChatHistoryDaoImpl() {
		em = DBUtil.em;
	}

	public Message saveMessage(Message message) throws UserException {
		try {
			em.getTransaction().begin();
			ChatHistory chathistory = new ChatHistory();
			chathistory.setUser(message.getSender());
			em.persist(chathistory);

			Query user_exist = em.createQuery("select user from User user where user_id in(?,?)");
			user_exist.setParameter(1, message.getSender().getId());
			user_exist.setParameter(2, message.getReceiver().getId());

			List result = user_exist.getResultList();
			if (result != null) {
				message.setChathistory(chathistory);
				em.persist(message);
				em.getTransaction().commit();

			}
			// else {
			// em.merge(message);
			// em.getTransaction().commit();
			// }
			/*
			 * else { em.flush(); em.clear(); em.merge(message); Query q =
			 * em.createQuery("update message m set chatHistoy_id_fk=? where sender_id=?");
			 * q.setParameter(1,chathistory.getId());
			 * q.setParameter(2,message.getSender().getId()); q.executeUpdate();
			 * em.getTransaction().commit(); }
			 */

		} catch (Exception e) {
			throw new UserException("User Already Exist");
		}
		return null;
	}

	public List<Message> findBySenderOrReceiver(User user) throws UserException {
		try {
			Query search = em.createQuery("from Message where sender_id=? or receiver_id=?");
			search.setParameter(1, user.getId());
			search.setParameter(2, user.getId());

			@SuppressWarnings("unchecked")
			List<Message> messageList = search.getResultList();
			return messageList;
		} catch (Exception e) {
			throw new UserException("No Messages Against Entered Id");
		}
	}

	public List<ChatHistory> getAllChatHistory() {
		List<ChatHistory> chat = new ArrayList<ChatHistory>();
		List<Message> msgs = new ArrayList<Message>();
		TypedQuery<Message> mm = em.createQuery("select m from Message m", Message.class);
		msgs = mm.getResultList();
		chat.add(new ChatHistory(msgs));

		return chat;
	}

}