package com.cg.chatbox.dao;

import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;

public interface ChatHistoryDao {
	public Message saveMessage(Message message) throws UserException ;

	public List<Message> findBySenderOrReceiver(User user) throws UserException ;

	public List<ChatHistory> getAllChatHistory();

}
