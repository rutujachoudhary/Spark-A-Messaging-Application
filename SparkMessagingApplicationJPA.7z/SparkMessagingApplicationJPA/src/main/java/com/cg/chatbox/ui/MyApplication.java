package com.cg.chatbox.ui;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;
import com.cg.chatbox.service.ChatHistoryService;
import com.cg.chatbox.service.ChatHistoryServiceImpl;

public class MyApplication {

	static ChatHistoryService service;

	public static void main(String[] args) {

		service = new ChatHistoryServiceImpl();
		ChatHistory chat = null;
		Message message = null;
		User sender = null;
		User receiver = null;
		User user = null;
		int choice = 0;

		do {
			/* User needs to select one of the choices to perform the operation */
			System.out.println("1.Add Message");
			System.out.println("2.View the Chat History");
			System.out.println("3.Search Message");
			System.out.println("4.Exit");

			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();

			switch (choice) {
			/* For case 1, taking text, details of sender and receiver as input from user */
			case 1:
				System.out.println("Write Message: ");
				Scanner s = new Scanner(System.in).useDelimiter("\n");
				String text = s.next();
				System.out.println(text);
				System.out.println("Id of Sender: ");
				int senderId = scr.nextInt();
				System.out.println("Send By: ");
				String senderName = scr.next();
				System.out.println("Id of Receiver: ");
				int receiverId = scr.nextInt();
				sender = new User(senderId, senderName);
				System.out.println("Received by: ");
				String receiverName = scr.next();
				receiver = new User(receiverId, receiverName);
				Timestamp date = new Timestamp(System.currentTimeMillis());
				System.out.println("Deliverd at: " + date);

				message = new Message(text, date, sender, receiver, chat);

				try {
					service.addMessage(message);
				} catch (UserException e) {
					e.getMessage();
				}

				break;

			/* In case 2, the total chat ever happened id is getting displayed */
			case 2:
				List<ChatHistory> chathistory = null;
				chathistory = service.getAllChatHistory();

				for (ChatHistory chathis : chathistory) {
					System.out.println(chathis.getMessage());
				}
				break;

			// The case 3, gives all the messages against id entered by the user
			case 3:
				System.out.println("Enter the Id for which you want to display the messages: ");
				int searchId = scr.nextInt();
				user = new User(searchId, null);
				List<Message> allmsg = new ArrayList<Message>();
				try {
					allmsg = service.searchBySenderOrReceiver(user);
				} catch (UserException e) {
					e.getMessage();
				}
				System.out.println(allmsg);

				break;
			case 4:
				System.exit(0);
			}
		} while (choice != 0);
	}

}
