package com.cg.chatbox.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.chatbox.dao.ChatHistoryDao;
import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.exception.UserException;

/**
 * @author rutchoud
 * This is the Service class which is the implementation of service interface
 */


@Transactional
@Service															/** @Service annotation is used with classes that provide some business functionalities. */
public class ChatHistoryServiceImpl implements ChatHistoryService {
	@Autowired
	ChatHistoryDao dao;

	static int msg_id = 1;
	
	/**
	 * @author rutchoud
	 * This is the saveMessage method which adds the messages in the database.
	 * @param here object of message is passed as an argument
	 * @exception If we try adding message with existing user id it will throw exception try adding message with another id
	 * @return object of Message.
	 */

	@Override
	public Message addMessage(Message message) {
		message.setId(msg_id);
		msg_id++;

		Message ms = dao.getMessageById(message.getSender().getId());
		if (ms != null) {
			throw new UserException("User With Same Id Already Present Try Adding with Another Id");
		} else {
			Message mss = dao.getMessageById(message.getReceiver().getId());
			if(mss!=null) {
				throw new UserException("User With Same Id Already Present Try Adding with Another Id");
			}
			else {
			Message msg = dao.saveMessage(message);
			return msg;
		}
		}
//		return ms;
	}

	@Override
	public Message getMessageById(Integer id) {
		return dao.getMessageById(id);
	}
	
	/**
	 * @author rutchoud
	 * This is the searchMessage method which searches the messages previously added in the database against user.
	 * @Exception when we want to retrieve the messages against user who is not yet saved it throws the exception No messages.
	 * @param here id in the form integer is passed as argument here. 
	 * @return List of Message.
	 */
	
	@Override
	public List<Message> searchBySenderOrReceiver(Integer id) throws UserException {
		List<Message> msgList = dao.findBySenderOrReceiver(id);
		if (msgList.isEmpty()) {
			throw new UserException("There are no messages against entered id because no user with this id");
		}
		return msgList;
	}
	/**
	 * @author rutchoud
	 * This is the getAllChatHistory method which retrieves all the messages previously added in the list of chathistory against user.
	 * @exception when there are no messages in the database then it will throws the exception No Chathistory yet.
	 * @param no args.
	 * @return List of chathistory.
	 */

	@Override
	public List<ChatHistory> getAllChatHistory() {
		List<ChatHistory> chat = dao.getAllChatHistory();
		if (chat.isEmpty()) {
			throw new UserException("No Messages Added Yet");
		}
		return chat;
	}

}
