package com.cg.chatbox.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.exception.UserException;
import com.cg.chatbox.service.ChatHistoryService;

/**
 * @author rutchoud
 * This is the Controller class which interprets with user input and transform it into a
 *  model that is represented to the user by the view.
 */

/** @Controller annotation indicates that the class serves the role of a Controller */
@Controller
public class Mycontroller {

	@Autowired
	ChatHistoryService service;

	ChatHistory chat;

	/** @RequestMapping annotation is used to map index.jsp page . 
	 * 
	 * @return redirects to the option page.
	 * */
	@RequestMapping(name = "option", method = RequestMethod.GET)
	// @GetMapping(value = "login")
	public String page() {
		return "option";
	}

	/**
	 * This method map to http://localhost:9090/SparkMessagingApplicationSpringMvcJPA/addinfo
	 * 
	 * @param @ModelAttribute message
	 *            
	 * @return ModelAndView
	 */
	@GetMapping(value = "addinfo")
	public ModelAndView addMessage(@ModelAttribute("message") Message message) {
		return new ModelAndView("added");
	}

	@PostMapping("add")
	public ModelAndView addAllMessage(@ModelAttribute("message") Message message) {
		Message mymessage = service.addMessage(message);
		return new ModelAndView("added", "key", mymessage);
	}

	/**
	 * This method map to
	 * http://localhost:9090/SparkMessagingApplicationSpringMvcJPA/addinfo
	 * 
	 * @return ModelAndView
	 */
	@GetMapping("show")
	public ModelAndView show() {
		List<ChatHistory> chathisList = service.getAllChatHistory();
		return new ModelAndView("showall", "showkey", chathisList);
	}

	/**
	 * This method map to http://localhost:9090/SparkMessagingApplicationSpringMvcJPA/show
	 * 
	 * @param @RequestParam userid
	 *            
	 * @return ModelAndView
	 */
	@GetMapping("search")
	public ModelAndView search() {
		return new ModelAndView("searchmessage");
	}

	@PostMapping("searchmsg")
	public ModelAndView searchMessage(@RequestParam("userid") int id, Model m) {
		List<Message> msgList = service.searchBySenderOrReceiver(id);
		m.addAttribute("mk", msgList);
		return new ModelAndView("searchmessage", "mk", msgList);
	}

	/**
	 * @author rutchoud
	 * @ExceptionHandler Annotation used for handling exceptions which are thrown
	 *                   from this controller class.
	 * @return model means the new view error/error.
	 */

	@ExceptionHandler(UserException.class)
	public ModelAndView handleException(UserException u) {
		ModelAndView model = new ModelAndView("error/error");
		model.addObject("errmsgkey", u.getMessage());
		return model;

	}
}
