package com.cg.chatbox.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;

/**
 * @author rutchoud
 * This is the Repository class which makes connectivity with database in the project.
 */
/**
 * @Repository annotation is used to indicate that the class provides the mechanism for 
 * storage, retrieval, search operation on objects.
*/
@Repository
public class ChatHistoryDaoImpl implements ChatHistoryDao {

	@PersistenceContext
	EntityManager entitymanager;

	List<Message> myMessages = new ArrayList<>();
	List<ChatHistory> allChatHistory = new ArrayList<>();

	/**
	 * @author rutchoud
	 * This is the saveMessage method which adds the messages in the database.
	 * @param here object of message is passed as an argument
	 * @return object of Message.
	 */
	
	@Override
	public Message saveMessage(Message message) {

		ChatHistory chathistory = new ChatHistory();
		chathistory.setUser(message.getSender());
		entitymanager.persist(chathistory);
		
		message.setChathistory(chathistory);
		entitymanager.persist(message);
		entitymanager.flush();
		/*Message mess = getMessageById(message.getSender().getId());
		if(mess == null) {
			message.setChathistory(chathistory);
			entitymanager.persist(message);
			entitymanager.flush();
		}
		else {
			Message newmess = new Message();
			newmess.setText(message.getText());
			newmess.setDate(message.getDate());
			entitymanager.persist(newmess);
			entitymanager.flush();
		}*/
		return message;
	}

	
	/**
	 * @author rutchoud
	 * This is the searchMessage method which searches the messages previously added in the database against user.
	 * @Exception when we want to retrieve the messages against user who is not yet saved it throws the exception No messages.
	 * @param here id in the form integer is passed as argument here. 
	 * @return List of Message.
	 */
	
	@Override
	public List<Message> findBySenderOrReceiver(Integer id) {
		Query search = entitymanager.createQuery("from Message where sender_id=?1 or receiver_id=?1");
		search.setParameter(1, id);
		@SuppressWarnings("unchecked")
		List<Message> messageList = search.getResultList();
		return messageList;
	}

	/**
	 * @author rutchoud
	 * This is the getAllChatHistory method which retrieves all the messages previously added in the list of chathistory against user.
	 * @exception when there are no messages in the database then it will throws the exception No Chathistory yet.
	 * @param no args
	 * @return List of chathistory.
	 */

	@SuppressWarnings("unchecked")
	@Override
	public List<ChatHistory> getAllChatHistory() {
		Query all = entitymanager.createQuery("from Message");
		allChatHistory = all.getResultList();
		return allChatHistory;
	}

	/**
	 * @author rutchoud
	 * This is the getMessageById method which retrieves all the messages against particular id.
	 * @param it accepts id in the form integer and returns message.
	 * @return List of chathistory.
	 */

	@Override
	public Message getMessageById(Integer id) {
		Message m = null;
		try {
		Query find = entitymanager.createQuery("from Message where sender_id=?1 or receiver_id=?1");
		find.setParameter(1, id);
		m = (Message) find.getSingleResult();
		}catch(NoResultException e) {
	}
		return m;
	}
	

}
