package com.cg.chatbox.dto;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * This is the DTO class of User 
 * @Author Rutuja Choudhary
 */
@Component("user")							/** @Component annotation is used to denote a class as Component */
@Scope("prototype")							/**  @Scope("prototype") This scopes a single bean definition to have any number of object instances.*/
public class User {
	private String name;					/** This attribute is used to accept the name of user in String format*/
	private int id;							/** This attribute is used to accept the id of user in integer*/
	
	public User() {
	}

	public User(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}

	public String getName() {
		return name;
	}

	/** calling getters and setter */
	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/** creating toString */
	@Override
	public String toString() {
		return "User [name=" + name + ", id=" + id + "]";
	}
	
	

}
