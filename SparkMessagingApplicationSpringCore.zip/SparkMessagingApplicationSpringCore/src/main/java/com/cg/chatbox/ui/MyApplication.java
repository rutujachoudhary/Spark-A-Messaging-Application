package com.cg.chatbox.ui;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.chatbox.config.JavaConfig;
import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;
import com.cg.chatbox.service.ChatHistoryService;

/**
 * This is the Main class which makes use of all the functionalities in the
 * project.
 * @Author Rutuja Choudhary
 */

@Component
public class MyApplication {
	@Autowired
	ChatHistoryService chathistoryservice;

	static ChatHistoryService service;
	static User sender;
	static User receiver;

	@PostConstruct
	public void init() {
		service = this.chathistoryservice;
	}
	
	/**
	 * This is the main method which makes use of all the functionalities in the
	 * project.
	 * @param args Unused.
	 * @return Nothing.
	 */

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);
		List<Message> msgList = new ArrayList<Message>();
		int choice = 0;

		do {

			System.out.println("1.Add Message");
			System.out.println("2.Search Message");
			System.out.println("3.View the Chat History");
			System.out.println("4.Exit");

			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();

			switch (choice) {
			
			/** Case for adding Messages into the list by taking input from users */
			case 1:
				System.out.println("Write Message: ");
				Scanner s = new Scanner(System.in).useDelimiter("\n");
				String text = s.next();
				System.out.println(text);
				Timestamp date = new Timestamp(System.currentTimeMillis());
				System.out.println("Deliverd at: " + date);
				System.out.println("Send By: ");
				String senderName = scr.next();
				System.out.println(senderName + "'s Id: ");
				int senderId = scr.nextInt();
				sender = (User) context.getBean("user");
				sender.setId(senderId);
				sender.setName(senderName);
				System.out.println("Received by: ");
				String receiverName = scr.next();
				System.out.println(receiverName + "'s Id: ");
				int receiverId = scr.nextInt();
				receiver = (User) context.getBean("user");
				receiver.setId(receiverId);
				receiver.setName(receiverName);
				Message message = (Message) context.getBean("message");
				message.setText(text);
				message.setDate(date);
				message.setSender(sender);
				message.setReceiver(receiver);

				service.addMessage(message);
				System.out.println(service.addMessage(message));
				System.out.println(senderId + " : " + senderName + " sent- " + text + " at: " + date + ", " + receiverId
						+ " : " + receiverName + " received");
				System.out.println(receiverId + " :: " + receiverName + " received");

				ChatHistory chathistory = (ChatHistory) context.getBean("chathistory");
				msgList.add(message);
				chathistory.setMessage(msgList);
				service.addChatHistory(chathistory);

				break;
				
				/** Case for searching messages against the entered user Id
				 *  @Exception when there are no messages against entered user id, exception will be thrown.
				 * */
			case 2:
				System.out.println("Enter Id for which messages to be searched: ");
				int Id = scr.nextInt();
				User user = (User) context.getBean("user");
				user.setId(Id);
				try {
					List<Message> msg = service.searchBySenderOrReceiver(user);
					System.out.println(msg);
				} catch (UserException u) {
					System.out.println(u.getMessage());
				}
				break;
				
				/** Case for displaying All Chat history ever happened 
				 * @Exception when there no conversation ever happened it will throw the exception 
				 * */
			case 3:
				try {
					List<ChatHistory> chathis = service.getAllChatHistory();
					for (ChatHistory chat : chathis) {
						System.out.println(chat.getMessage());
					}
				} catch (UserException u) {
					System.out.println(u.getMessage());
				}
				break;

			case 4:
				System.exit(0);

			}
		} while (choice != 0);
	}
}
