package com.cg.chatbox.dto;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * This is the DTO class of ChatHistory 
 * @Author Rutuja Choudhary
 */

@Component("chathistory")						/** @Component annotation is used to denote a class as Component */
@Scope("prototype")
public class ChatHistory {		
	private User user;							
	private List<Message> message;				

	public ChatHistory() {

	}

	/** calling getters and setter */
	public ChatHistory(List<Message> message) {
		super();
		this.message = message;
	}

	public List<Message> getMessage() {
		return message;
	}

	public void setMessage(List<Message> message) {
		this.message = message;
	}

	/** creating toString */
	@Override
	public String toString() {
		return "ChatHistory [message=" + message + "]";
	}
	
	

	
}
