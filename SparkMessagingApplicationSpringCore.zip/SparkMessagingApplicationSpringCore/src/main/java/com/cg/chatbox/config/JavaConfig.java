package com.cg.chatbox.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * This class is responsible for creating beans of all the classes under given package.
 * @Author: Rutuja Choudhary.
 * */ 
 

@Configuration								/** @Configuration annotation helps in Spring annotation based configuration.*/
@ComponentScan("com.cg.chatbox")			/** @ComponentScan is used to specify base package. */
public class JavaConfig {

}
