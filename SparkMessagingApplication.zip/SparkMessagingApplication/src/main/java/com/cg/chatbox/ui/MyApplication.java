package com.cg.chatbox.ui;

import java.sql.Timestamp;
import java.util.List;
import java.util.Scanner;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;
import com.cg.chatbox.service.ChatHistoryService;
import com.cg.chatbox.service.ChatHistoryServiceImpl;

public class MyApplication {

	public static void main(String[] args) {
		ChatHistoryService service = new ChatHistoryServiceImpl();
		Message message = null;
		User sender = null;
		User receiver = null;
		int choice = 0;

		do {

			System.out.println("1.Add Message");
			System.out.println("2.Search Message");
			System.out.println("3.View the Chat History");
			System.out.println("4.Exit");

			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Write Message: ");
				Scanner s = new Scanner(System.in).useDelimiter("\n");
				String text = s.next();
				System.out.println(text);
				Timestamp date = new Timestamp(System.currentTimeMillis());
				System.out.println("Deliverd at: " + date);
				System.out.println("Send By: ");
				String senderName = scr.next();
				System.out.println(senderName + "'s Id: ");
				int senderId = scr.nextInt();
				sender = new User(senderName, senderId);
				System.out.println("Received by: ");
				String receiverName = scr.next();
				System.out.println(receiverName + "'s Id: ");
				int receiverId = scr.nextInt();
				receiver = new User(receiverName, receiverId);

				message = new Message(text, date, sender, receiver);
				service.addMessage(message);
				System.out.println(service.addMessage(message));
				System.out.println(senderId + " : " + senderName + " sent- " + text + " at: " + date + ", " + receiverId
						+ " : " + receiverName + " received");
				System.out.println(receiverId + " :: " + receiverName + " received");
				break;

			case 2:
				try {
					System.out.println("Enter Id for which messages to be searched: ");
					int Id = scr.nextInt();
					User user = new User(null, Id);
					List<Message> msg = service.searchBySenderOrReceiver(user);
					System.out.println(msg);
				} catch (UserException u) {
					System.out.println(u.getMessage());
				}
				break;

			case 3:

				List<ChatHistory> chathistory = service.getAllChatHistory();
				for (ChatHistory chathis : chathistory) {
					System.out.println(chathis);
				}
				break;

			case 4:
				System.exit(0);

			}
		} while (choice != 0);
	}
}
