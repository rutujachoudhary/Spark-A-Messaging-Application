package com.cg.chatbox.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;
import com.cg.chatbox.util.DBUtil;

public class ChatHistoryDaoImpl implements ChatHistoryDao {

	public Message saveMessage(Message message) {
		DBUtil.messages.add(message);
		return message;
	}

	public List<Message> findBySenderOrReceiver(User user) throws UserException {
		List<Message> messageList = new ArrayList<Message>();
		
		 /*for(Message m: DBUtil.messages)
		  if(m.getSender().getId()==user.getId()||m.getReceiver().getId()==user.getId()) 
		  messageList.add(m);
		  
		  if(messageList.isEmpty()) throw new UserException("Id not found");*/
		
		for (int i = 0; i < DBUtil.messages.size(); i++)
			if (DBUtil.messages.get(i).getSender().getId() == user.getId()
					|| DBUtil.messages.get(i).getReceiver().getId() == user.getId()) {
				Message message = DBUtil.messages.get(i);
//				System.out.println(message);
				messageList.add(message);
			}
		if (messageList.isEmpty())
			throw new UserException("There are no messages against entered id");
		return messageList;
	}

	public List<ChatHistory> getAllChatHistory() {
		return DBUtil.chathistory;

	}
}
