package com.cg.chatbox.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;

public class DBUtil {
	public static List<Message> messages = new ArrayList<Message>();
	public static List<ChatHistory> chathistory = new ArrayList<ChatHistory>();
	
	
	static {
		Message firstMessage = new Message("Hi", new Timestamp(System.currentTimeMillis()), new User ("Rutuja",01), new User ("Tanaya",02));
		Message secondMessage = new Message("Hello",new Timestamp(System.currentTimeMillis()), new User("Tanaya",02), new User("Rutuja",01));
		Message thirdMessage = new Message("Hello",new Timestamp(System.currentTimeMillis()), new User("Nikita",5), new User("Sonal",6));
		Message fourthMessage = new Message("Sup?",new Timestamp(System.currentTimeMillis()), new User("Rutuja",01), new User("Tanaya",02));
		Message fifthMessage = new Message("Nothing",new Timestamp(System.currentTimeMillis()), new User("Tanaya",02), new User("Rutuja",01));
		
		messages.add(firstMessage);
		messages.add(secondMessage);
		messages.add(thirdMessage);
		messages.add(fourthMessage);
		messages.add(fifthMessage);
		
		chathistory.add(new ChatHistory(messages));
				
	}
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
}
