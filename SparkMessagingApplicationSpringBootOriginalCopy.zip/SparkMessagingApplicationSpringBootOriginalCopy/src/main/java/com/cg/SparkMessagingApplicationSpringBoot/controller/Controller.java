package com.cg.SparkMessagingApplicationSpringBoot.controller;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.SparkMessagingApplicationSpringBoot.dto.ChatHistory;
import com.cg.SparkMessagingApplicationSpringBoot.dto.Message;
import com.cg.SparkMessagingApplicationSpringBoot.dto.User;
import com.cg.SparkMessagingApplicationSpringBoot.exception.UserException;
import com.cg.SparkMessagingApplicationSpringBoot.service.ChatHistoryService;

/**
 * @author rutchoud
 * This is the Controller class which interprets with user input.
 */

/**
 * @RestController is a specialized version of the controller. It includes
 *                 the @Controller and @ResponseBody annotations
 */

@RestController
@RequestMapping("/chathistory")
public class Controller {

	@Autowired
	ChatHistoryService service;

	/**
	 * @author rutchoud
	 * 
	 * @RequestMapping annotation is used to map with /add given in URL .
	 * 
	 */

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ResponseEntity<Message> addMessage(@RequestParam("text") String text, @RequestParam("date") Timestamp date,
			@RequestParam("sender_id") int senderid, @RequestParam("sender_name") String sendername,
			@RequestParam("receiver_id") int receiverid, @RequestParam("receiver_name") String receivername,
			@RequestParam("chat_histoy_id_fk") int chathistoryid) {

		User user = new User();
		user.setId(senderid);
		user.setName(sendername);

		User userone = new User();
		userone.setId(receiverid);
		userone.setName(receivername);

		ChatHistory chatHistory = new ChatHistory();
		chatHistory.setUser(user);

		Message message = new Message();
		message.setText(text);
		message.setDate(new Timestamp(System.currentTimeMillis()));
		message.setSender(user);
		message.setReceiver(userone);
		message.setChathistory(chatHistory);

		Message mess = service.addMessage(message);
		return new ResponseEntity<Message>(mess, HttpStatus.OK);
	}

	/**
	 * @author rutchoud This method map to /show method given in URL
	 * 
	 *         HttpStatus It Marks a method with the status code() and reason() that
	 *         should be returned.
	 * 
	 * @return This method returns List of ChatHistory
	 */

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/show", method = RequestMethod.GET)
	public ResponseEntity<List<ChatHistory>> getAllChathistory() {
		List<ChatHistory> ch = service.showAllChatHistory();
		return new ResponseEntity(ch, HttpStatus.OK);
	}

	/**
	 * This method map to /search given in URL
	 * 
	 * @RequestParam uid
	 * 
	 * @return The List of messages we want to see against entered Id.
	 */

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public ResponseEntity<List<Message>> searchMessage(@RequestParam("uid") Integer id) {
		List<Message> msgList = service.searchBySenderOrReceiverId(id);
		return new ResponseEntity(msgList, HttpStatus.OK);
	}

	/**
	 * @author rutchoud
	 * @ExceptionHandler Annotation used for handling exceptions which are thrown
	 *                   from this controller class.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@ExceptionHandler({ UserException.class })
	public ResponseEntity handleTestException(UserException u) {
		return new ResponseEntity(u.getMessage(), HttpStatus.NOT_FOUND);

	}
}
