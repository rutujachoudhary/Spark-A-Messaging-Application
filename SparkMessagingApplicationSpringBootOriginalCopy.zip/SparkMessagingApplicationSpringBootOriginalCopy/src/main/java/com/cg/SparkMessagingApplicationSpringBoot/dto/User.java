package com.cg.SparkMessagingApplicationSpringBoot.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This is the DTO class of User
 * 
 * @Author Rutuja Choudhary
 */

@Entity
@Table(name = "User")
public class User {
	@Id
	@Column(name = "user_id")
	private int id;								/** This attribute is used to accept the name of user in String format*/
	@Column(name = "user_name")
	private String name;						/** This attribute is used to accept the id of user in integer*/

	public User() {
	}

	public User(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + "]";
	}

}
