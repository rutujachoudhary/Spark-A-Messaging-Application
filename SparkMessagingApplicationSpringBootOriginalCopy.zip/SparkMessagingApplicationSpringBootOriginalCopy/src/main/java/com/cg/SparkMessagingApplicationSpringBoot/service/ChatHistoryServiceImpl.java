package com.cg.SparkMessagingApplicationSpringBoot.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SparkMessagingApplicationSpringBoot.dao.ChatHistoryDao;
import com.cg.SparkMessagingApplicationSpringBoot.dto.ChatHistory;
import com.cg.SparkMessagingApplicationSpringBoot.dto.Message;
import com.cg.SparkMessagingApplicationSpringBoot.exception.UserException;


/**
 * @author rutchoud
 * This is the Service class which is the implementation of service interface
 */


@Service																/** @Service annotation is used with classes that provide some business functionalities. */
@Transactional
public class ChatHistoryServiceImpl implements ChatHistoryService {

	@Autowired
	ChatHistoryDao dao;
	static final Logger logger = Logger.getLogger(ChatHistoryServiceImpl.class);

	/**
	 * @author rutchoud
	 * This is the saveMessage method which adds the messages in the database.
	 * @param here object of message is passed as an argument
	 * @return object of Message.
	 */
	
	
	@Override
	public Message addMessage(Message message) {
		PropertyConfigurator.configure(
				"D:\\JavaDemoRC\\SparkMessagingApplicationSpringBootOriginalCopy\\src\\main\\java\\resources\\log4j.properties");

		List<Message> msgList = dao.findBySenderOrReceiverId(message.getSender().getId());
		List<Message> msgListReceiver = dao.findBySenderOrReceiverId(message.getReceiver().getId());
		Integer chathistoryid = dao.findChatBySenderOrReceiverId(message.getSender().getId());
		if (chathistoryid != null && msgList != null) {
			Integer msg = dao.saveMessage(message.getText(), message.getDate(), message.getSender().getId(),
					message.getReceiver().getId(), chathistoryid);
			logger.info("Message added successfully");
			return null;
		} else if (chathistoryid != null && msgListReceiver != null) {
			Integer msg = dao.saveMessage(message.getText(), message.getDate(), message.getSender().getId(),
					message.getReceiver().getId(), chathistoryid);
			logger.info("Message added successfully");
			return null;
		}

		else {
			Message msg = dao.save(message);
			logger.info("Message added successfully");
			return msg;
		}
	}

	/**
	 * @author rutchoud
	 * This is the searchMessage method which searches the messages previously added in the database against user.
	 * @Exception when we want to retrieve the messages against user who is not yet saved it throws the exception No messages.
	 * @param here id in the form integer is passed as argument here. 
	 * @return List of Message.
	 */
	
	@Override
	public List<Message> searchBySenderOrReceiverId(Integer id) {
		PropertyConfigurator.configure(
				"D:\\JavaDemoRC\\SparkMessagingApplicationSpringBootOriginalCopy\\src\\main\\java\\resources\\log4j.properties");
		List<Message> msgList = dao.findBySenderOrReceiverId(id);
		if (msgList.isEmpty()) {
			throw new UserException("There are no messages against entered id because no user with this id");
		}
		logger.info("Messages Against Entered Id searched");
		return msgList;
	}

	/**
	 * @author rutchoud
	 * This is the getAllChatHistory method which retrieves all the messages previously added in the list of chathistory against user.
	 * @exception when there are no messages in the database then it will throws the exception No Chathistory yet.
	 * @param no args
	 * @return List of chathistory.
	 */
	
	@Override
	public List<ChatHistory> showAllChatHistory() {
		PropertyConfigurator.configure(
				"D:\\JavaDemoRC\\SparkMessagingApplicationSpringBootOriginalCopy\\src\\main\\java\\resources\\log4j.properties");
		List<ChatHistory> chathisList = dao.findAllChatHistory();
		if (chathisList.isEmpty()) {
			throw new UserException("No Conversation happened yet");
		}
		
		logger.info("Chathistory Shown");
		return chathisList;
	}

}
