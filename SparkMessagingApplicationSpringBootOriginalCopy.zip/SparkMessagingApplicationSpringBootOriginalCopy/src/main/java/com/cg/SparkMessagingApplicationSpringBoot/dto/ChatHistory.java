package com.cg.SparkMessagingApplicationSpringBoot.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

/**
 * This is the DTO class of ChatHistory
 * 
 * @Author Rutuja Choudhary
 */

@Entity
@Table(name = "chat_history")
public class ChatHistory {
	@Id
	@Column(name = "chatHistory_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	private User user;

	/*
	 * public ChatHistory(int id, User user, List<Message> message) { super();
	 * this.id = id; this.user = user; this.message = message; }
	 */

	@JsonManagedReference
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "chathistory", cascade = CascadeType.ALL)
	private List<Message> message;

	public ChatHistory() {
	}

	public ChatHistory(List<Message> message) {
		super();
		this.message = message;
	}

	public ChatHistory(int id) {
		super();
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Message> getMessage() {
		return message;
	}

	public void setMessage(List<Message> message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "ChatHistory [message=" + message + "]";
	}

}
