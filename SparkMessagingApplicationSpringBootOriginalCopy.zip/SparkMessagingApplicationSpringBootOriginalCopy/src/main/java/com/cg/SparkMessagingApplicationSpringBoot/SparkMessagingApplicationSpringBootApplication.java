package com.cg.SparkMessagingApplicationSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author rutchoud
 * 
 * @SpringBootApplication  * Using this annotation it will wraps commonly used annotation with spring boot.
 * it will also auto configures the whole framework.
 * 
 * @ComponentScan this annotation used for scanning all beans in this package.
 */

@SpringBootApplication
//@ComponentScan("com.cg.SparkMessagingApplicationSpringBoot")
public class SparkMessagingApplicationSpringBootApplication {

	public static void main(String[] args) {
		/**
		 * This run() method will starts spring then creates spring context and applies
		 * annotations and sets ups the container.
		 */

		SpringApplication.run(SparkMessagingApplicationSpringBootApplication.class, args);
		System.out.println("In Project");
	}

}
