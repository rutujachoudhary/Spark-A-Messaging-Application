package com.cg.SparkMessagingApplicationSpringBoot.dao;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.SparkMessagingApplicationSpringBoot.dto.ChatHistory;
import com.cg.SparkMessagingApplicationSpringBoot.dto.Message;

public interface ChatHistoryDao extends JpaRepository<Message, Integer> {

	/**
	 * @author rutchoud
	 * 
	 * @Query This annotation in Spring Data provides way to define a query that we
	 *        can execute.
	 */

	@Query(nativeQuery = true, value = "select * from Message m where m.sender_id=:userid or m.receiver_id=:userid")
	public List<Message> findBySenderOrReceiverId(@Param("userid") Integer id);

	@Query("select c from ChatHistory c join fetch c.message")
	public List<ChatHistory> findAllChatHistory();

	@Query(nativeQuery = true, value = "select chat_history_id from chat_history m where user_id=:userid")
	public Integer findChatBySenderOrReceiverId(@Param("userid") Integer id);

	/**
	 * @Modifying is used to enhance the @Query annotation to execute not only
	 *            SELECT queries but also INSERT, UPDATE, DELETE, and even DDL
	 *            queries.
	 */

	@Modifying
	@Query(nativeQuery = true, value = "Insert into Message (text,date,sender_id,receiver_id,chat_histoy_id_fk) values(:text, :date,:sender_id,:reciever_id,:chat_histoy_id_fk)")
	public Integer saveMessage(@Param("text") String text, @Param("date") Timestamp date,
			@Param("sender_id") Integer sender_id, @Param("reciever_id") Integer reciever_id,
			@Param("chat_histoy_id_fk") int chat_histoy_id_fk);

}
