package com.cg.chatbox.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.chatbox.exception.UserException;

public class DBUtil {
	static Connection conn;

	public static Connection getConnection() throws UserException {
		Properties prop = new Properties();

		try {
			InputStream it = new FileInputStream("src/main/resources/jdbc.properties");
			prop.load(it);

			if (prop != null) {
				String driver = prop.getProperty("jdbc.Driver");
				String url = prop.getProperty("jdbc.url");
				String uname = prop.getProperty("jdbc.username");
				String upass = prop.getProperty("jdbc.password");

				conn = DriverManager.getConnection(url, uname, upass);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new UserException("File Not Found");
		} catch (IOException e) {
			e.printStackTrace();
			throw new UserException("File can not Open");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new UserException("Connection not Established");
		}

		return conn;

	}
}
