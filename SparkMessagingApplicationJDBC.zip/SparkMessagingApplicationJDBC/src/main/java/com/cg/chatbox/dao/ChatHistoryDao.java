package com.cg.chatbox.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;

public interface ChatHistoryDao {

	public Message saveMessage(Message message) throws UserException, SQLException;

	public List<Message> findBySenderOrReceiver(User user) throws SQLException, UserException;

	public List<ChatHistory> getAllChatHistory() throws SQLException, UserException;

}
