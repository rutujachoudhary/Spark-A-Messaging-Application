package com.cg.chatbox.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;
import com.cg.chatbox.util.DBUtil;

public class ChatHistoryDaoImpl implements ChatHistoryDao {
	int count = 0;

	/* This Method performs adding new messages with adding users as well */
	public Message saveMessage(Message message) throws UserException, SQLException {
		Connection con = null;
		try {
			con = DBUtil.getConnection();

			String user_exist = "select user_id from user where user_id in (?,?)";
			PreparedStatement p;
			p = con.prepareStatement(user_exist);
			p.setInt(1, message.getSender().getId());
			p.setInt(2, message.getReceiver().getId());
			ResultSet result = p.executeQuery();
			while (result.next()) {
				count++;
			}

	} catch (SQLException e) {
			throw new UserException("Error While Selecting Id");
		}

		/* If Both Sender and Receiver are new then firstly adding them into user table
		 * and afterwards adding messages against their user id.*/
		if (count == 0) {
			String sender_insert = "Insert into user(user_id,user_name) values(?,?)";
			String receiver_insert = "Insert into user(user_id,user_name) values(?,?)";
			String query_insert = "Insert into message(text,date,sender_id,receiver_id) values(?,?,?,?)";

//			try {
				PreparedStatement pstm_sender = null;
				PreparedStatement pstm_receiver = null;
				PreparedStatement pstm = null;

				pstm_sender = con.prepareStatement(sender_insert);
				pstm_receiver = con.prepareStatement(receiver_insert);
				pstm = con.prepareStatement(query_insert);

				pstm_sender.setInt(1, message.getSender().getId());
				pstm_sender.setString(2, message.getSender().getName());
				pstm_sender.executeUpdate();

				pstm_receiver.setInt(1, message.getReceiver().getId());
				pstm_receiver.setString(2, message.getReceiver().getName());
				pstm_receiver.executeUpdate();

				pstm.setString(1, message.getText());
				pstm.setTimestamp(2, message.getDate());
				pstm.setInt(3, message.getSender().getId());
				pstm.setInt(4, message.getReceiver().getId());
				pstm.executeUpdate();

				pstm_sender.close();
				pstm_receiver.close();
				pstm.close();

			/*} catch (SQLException e) {
				throw new UserException("Error While Inserting Message");
			}
*/
		}
		// If one of the User is present, either sender or receiver then adding the
		// another one and after that adding messages.
		else if (count == 1) {
				PreparedStatement receiver = null;
				PreparedStatement message_insert = null;

				String receiver_insert = "Insert into user(user_id,user_name) values(?,?)";
				String receiver_id = "select user_id from user where user_id=?";
				String query_insert = "Insert into message(text,date,sender_id,receiver_id) values(?,?,?,?)";

				receiver = con.prepareStatement(receiver_id);
				receiver.setInt(1, message.getSender().getId());
				ResultSet r = receiver.executeQuery();
				if (r.next()) {
					receiver = con.prepareStatement(receiver_insert);
					receiver.setInt(1, message.getReceiver().getId());
					receiver.setString(2, message.getReceiver().getName());
					receiver.executeUpdate();
				} else {
					receiver = con.prepareStatement(receiver_insert);
					receiver.setInt(1, message.getSender().getId());
					receiver.setString(2, message.getSender().getName());
					receiver.executeUpdate();
				}
				message_insert = con.prepareStatement(query_insert);

				message_insert.setString(1, message.getText());
				message_insert.setTimestamp(2, message.getDate());
				message_insert.setInt(3, message.getSender().getId());
				message_insert.setInt(4, message.getReceiver().getId());
				message_insert.executeUpdate();

				receiver.close();
				message_insert.close();
				con.close();
		}

		// If both sender and receiver is present then just adding the messages
		else {
			String insert_message = "Insert into message(text,date,sender_id,receiver_id) values(?,?,?,?)";

			PreparedStatement ps = con.prepareStatement(insert_message);
			ps.setString(1, message.getText());
			ps.setTimestamp(2, message.getDate());
			ps.setInt(3, message.getSender().getId());
			ps.setInt(4, message.getReceiver().getId());
			ps.executeUpdate();
			
			ps.close();
			con.close();
			
		}

		return null;
	}

	// Getting list of all messages present in database
	public List<ChatHistory> getAllChatHistory() throws SQLException, UserException {
		List<Message> myMessageList = new ArrayList<Message>();
		List<ChatHistory> chatHistory = new ArrayList<ChatHistory>();
		Connection con = null;
		PreparedStatement pstm = null;

		try {
			con = DBUtil.getConnection();

			String message_show = "Select text,date,sender_id,receiver_id from message";
			pstm = con.prepareStatement(message_show);
			ResultSet result = pstm.executeQuery();
			while (result.next()) {
				Message msg = new Message();
				msg.setText(result.getString(1));
				msg.setDate(result.getTimestamp(2));
				msg.setSender(new User(result.getInt(3)));
				msg.setReceiver(new User(result.getInt(4)));

				myMessageList.add(msg);
			}
			chatHistory.add(new ChatHistory(myMessageList));
		} catch (SQLException e) {
			throw new UserException("No chat history available");
		} catch (UserException e) {
			
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
			}
		}
		return chatHistory;
	}

	// searching messages against a particular id of user
	public List<Message> findBySenderOrReceiver(User user) throws SQLException, UserException {
		List<Message> msgList = new ArrayList<Message>();
		PreparedStatement ptm = null;
		try {
			Connection connection = DBUtil.getConnection();
			String findMessage = "select text, date,sender_id,receiver_id from message where sender_id =? or receiver_id = ?";
			ptm = connection.prepareStatement(findMessage);

			ptm.setInt(1, user.getId());
			ptm.setInt(2, user.getId());

			ResultSet rs = ptm.executeQuery();
			while (rs.next()) {
				Message msgs = new Message();
				msgs.setText(rs.getString(1));
				msgs.setDate(rs.getTimestamp(2));
				msgs.setSender(new User(rs.getInt(3)));
				msgs.setReceiver(new User(rs.getInt(4)));
				msgList.add(msgs);
			}
		} catch (UserException e) {
		}
		if (msgList.isEmpty()) {
			throw new UserException("No Messages Against Entered User Id Because There Is No Such User Id Present");
		}
		return msgList;
	}

}
