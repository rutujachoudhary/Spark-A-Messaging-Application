package com.cg.chatbox.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.chatbox.dao.ChatHistoryDaoImpl;
import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;

public class ChatHistoryServiceImpl implements ChatHistoryService {
	ChatHistoryDaoImpl dao = new ChatHistoryDaoImpl();

	public Message addMessage(Message message) throws UserException, SQLException {
		return dao.saveMessage(message);
	}

	public List<Message> searchBySenderOrReceiver(User user) throws SQLException, UserException {
		return dao.findBySenderOrReceiver(user);
	}

	public List<ChatHistory> getAllChatHistory() throws SQLException, UserException {
		return dao.getAllChatHistory();
	}

}
