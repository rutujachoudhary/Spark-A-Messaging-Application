package com.cg.chatbox.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;

public interface ChatHistoryService {
	public Message addMessage(Message message) throws UserException, SQLException;

	public List<Message> searchBySenderOrReceiver(User user) throws SQLException, UserException;

	public List<ChatHistory> getAllChatHistory() throws SQLException, UserException;

}
